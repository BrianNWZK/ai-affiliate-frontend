
"use client";
import React, { useState, useEffect } from "react";
// ... full AffiliateMarketingAI code ...
